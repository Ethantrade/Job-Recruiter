const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs');

// Register or Login
router.post('/login', async (req, res) => {
    const { userId, userType, password } = req.body;
    try {
        let user = await User.findOne({ userId });

        if (!user) {
            const hashed = await bcrypt.hash(password, 10);
            user = new User({ userId, userType, password: hashed });
            await user.save();
            return res.status(201).json({ message: 'User registered', user });
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) return res.status(401).json({ message: 'Invalid credentials' });

        res.json({ message: 'Login successful', user });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;