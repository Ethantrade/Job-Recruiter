const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    userId: { type: String, required: true, unique: true },
    userType: { type: String, enum: ['jobseeker', 'company'], required: true },
    profile: { type: Object },
    password: { type: String }
});

module.exports = mongoose.model("User", userSchema);